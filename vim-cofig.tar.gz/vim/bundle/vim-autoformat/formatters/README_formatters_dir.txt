Formatprograms that are put here will be detected.
Note that globally available programs are also detected.
Read the general README.markdown file for more info on which formatprograms are supported.
